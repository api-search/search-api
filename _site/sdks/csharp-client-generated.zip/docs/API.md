# IO.Swagger.Model.API
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | name | 
**Description** | **string** | description of the API | 
**Image** | **string** | URL of an image representing the API | 
**BaseURL** | **string** | baseURL | 
**HumanURL** | **string** | humanURL | 
**Tags** | **List&lt;string&gt;** | tags to describe the API | [optional] 
**Properties** | [**List&lt;Property&gt;**](Property.md) | URLs | 
**Contact** | [**List&lt;Contact&gt;**](Contact.md) | Contact to reach if questions about API | 
**Meta** | [**List&lt;MetaInformation&gt;**](MetaInformation.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

