# IO.Swagger.Model.Contact
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FN** | **string** |  | 
**Email** | **string** |  | [optional] 
**OrganizationName** | **string** |  | [optional] 
**Adr** | **string** |  | [optional] 
**Tel** | **string** |  | [optional] 
**XGithub** | **string** |  | [optional] 
**Photo** | **string** |  | [optional] 
**VCard** | **string** |  | [optional] 
**Url** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

