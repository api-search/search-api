# IO.Swagger.Model.APIsJSON
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The name of the service described | 
**Description** | **string** | Description of the service | 
**Url** | **string** | URL where the apis.json file will live | 
**Image** | **string** | Image to represent the API | [optional] 
**Created** | **DateTime?** | Date when the file was created | [optional] 
**Modified** | **DateTime?** | Date when the file was modified | [optional] 
**SpecificationVersion** | **string** | APIs.json spec version, latest is 0.14 | [optional] 
**Apis** | [**List&lt;API&gt;**](API.md) | All the APIs of this service | [optional] 
**Maintainers** | [**List&lt;Maintainer&gt;**](Maintainer.md) | Maintainers of the apis.json file | [optional] 
**Tags** | **List&lt;Object&gt;** | Tags to describe the service | [optional] 
**Include** | [**List&lt;Include&gt;**](Include.md) | Links to other apis.json definitions included in this service. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

