# IO.Swagger.Model.Rule
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Description** | **string** |  | [optional] 
**DocumentationUrl** | **string** |  | [optional] 
**Recommended** | **bool?** |  | [optional] 
**Given** | [**Given**](Given.md) |  | 
**Resolved** | **bool?** |  | [optional] 
**Severity** | [**Severity**](Severity.md) |  | [optional] 
**Message** | **string** |  | [optional] 
**Tags** | **List&lt;string&gt;** |  | [optional] 
**Formats** | [**Formats**](Formats.md) |  | [optional] 
**Then** | [**List&lt;Then&gt;**](Then.md) |  | 
**Type** | **string** |  | [optional] 
**Extensions** | **Object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

