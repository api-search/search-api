# IO.Swagger.Api.SearchApi

All URIs are relative to *https://ibmwu99rx3.execute-api.us-east-1.amazonaws.com/staging*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AddAPI**](SearchApi.md#addapi) | **POST** /search/apis | Submit API
[**SearchAPIs**](SearchApi.md#searchapis) | **GET** /search/apis | Search APIs
[**SearchMaintainers**](SearchApi.md#searchmaintainers) | **GET** /search/maintainers | Search Maintainers

<a name="addapi"></a>
# **AddAPI**
> APIsJSON AddAPI (APIsJSON body)

Submit API

Submit an API to be included in the index.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AddAPIExample
    {
        public void main()
        {
            // Configure API key authorization: api_key
            Configuration.Default.AddApiKey("x-api-key", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("x-api-key", "Bearer");

            var apiInstance = new SearchApi();
            var body = new APIsJSON(); // APIsJSON | 

            try
            {
                // Submit API
                APIsJSON result = apiInstance.AddAPI(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SearchApi.AddAPI: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**APIsJSON**](APIsJSON.md)|  | 

### Return type

[**APIsJSON**](APIsJSON.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="searchapis"></a>
# **SearchAPIs**
> Search SearchAPIs (string search = null, string type = null, string maintainer = null, string limit = null, string page = null)

Search APIs

Searching across all APIs by keyword, property type, or maintainer.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SearchAPIsExample
    {
        public void main()
        {
            var apiInstance = new SearchApi();
            var search = search_example;  // string | Keyword to search by. (optional) 
            var type = type_example;  // string | Type to search by. (optional) 
            var maintainer = maintainer_example;  // string | Maintainer to search by. (optional) 
            var limit = limit_example;  // string |  (optional) 
            var page = page_example;  // string |  (optional) 

            try
            {
                // Search APIs
                Search result = apiInstance.SearchAPIs(search, type, maintainer, limit, page);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SearchApi.SearchAPIs: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | **string**| Keyword to search by. | [optional] 
 **type** | **string**| Type to search by. | [optional] 
 **maintainer** | **string**| Maintainer to search by. | [optional] 
 **limit** | **string**|  | [optional] 
 **page** | **string**|  | [optional] 

### Return type

[**Search**](Search.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="searchmaintainers"></a>
# **SearchMaintainers**
> Search SearchMaintainers (string search = null, string limit = null, string page = null)

Search Maintainers

Search across all maintainers.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SearchMaintainersExample
    {
        public void main()
        {
            var apiInstance = new SearchApi();
            var search = search_example;  // string | Keyword to search by. (optional) 
            var limit = limit_example;  // string |  (optional) 
            var page = page_example;  // string |  (optional) 

            try
            {
                // Search Maintainers
                Search result = apiInstance.SearchMaintainers(search, limit, page);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SearchApi.SearchMaintainers: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | **string**| Keyword to search by. | [optional] 
 **limit** | **string**|  | [optional] 
 **page** | **string**|  | [optional] 

### Return type

[**Search**](Search.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
