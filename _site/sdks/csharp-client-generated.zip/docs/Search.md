# IO.Swagger.Model.Search
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Meta** | [**SearchMeta**](SearchMeta.md) |  | 
**Data** | **List&lt;AnyOfSearchDataItems&gt;** | Listing of APIs in the JSON API format. | 
**Links** | [**SearchLinks**](SearchLinks.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

