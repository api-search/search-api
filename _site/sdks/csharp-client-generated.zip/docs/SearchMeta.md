# IO.Swagger.Model.SearchMeta
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Search** | **string** |  | [optional] 
**Type** | **string** |  | [optional] 
**Limit** | **int?** |  | 
**Page** | **int?** |  | 
**TotalPages** | **int?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

