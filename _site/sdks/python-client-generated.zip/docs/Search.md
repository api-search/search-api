# Search

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta** | [**SearchMeta**](SearchMeta.md) |  | 
**data** | **list[AnyOfSearchDataItems]** | Listing of APIs in the JSON API format. | 
**links** | [**SearchLinks**](SearchLinks.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

