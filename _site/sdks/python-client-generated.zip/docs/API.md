# API

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | name | 
**description** | **str** | description of the API | 
**image** | **str** | URL of an image representing the API | 
**base_url** | **str** | baseURL | 
**human_url** | **str** | humanURL | 
**tags** | **list[str]** | tags to describe the API | [optional] 
**properties** | [**list[ModelProperty]**](ModelProperty.md) | URLs | 
**contact** | [**list[Contact]**](Contact.md) | Contact to reach if questions about API | 
**meta** | [**list[MetaInformation]**](MetaInformation.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

