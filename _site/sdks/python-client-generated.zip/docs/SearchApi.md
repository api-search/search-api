# swagger_client.SearchApi

All URIs are relative to *https://ibmwu99rx3.execute-api.us-east-1.amazonaws.com/staging*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add_api**](SearchApi.md#add_api) | **POST** /search/apis | Submit API
[**search_apis**](SearchApi.md#search_apis) | **GET** /search/apis | Search APIs
[**search_maintainers**](SearchApi.md#search_maintainers) | **GET** /search/maintainers | Search Maintainers

# **add_api**
> APIsJSON add_api(body)

Submit API

Submit an API to be included in the index.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: api_key
configuration = swagger_client.Configuration()
configuration.api_key['x-api-key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['x-api-key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.SearchApi(swagger_client.ApiClient(configuration))
body = swagger_client.APIsJSON() # APIsJSON | 

try:
    # Submit API
    api_response = api_instance.add_api(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchApi->add_api: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**APIsJSON**](APIsJSON.md)|  | 

### Return type

[**APIsJSON**](APIsJSON.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **search_apis**
> Search search_apis(search=search, type=type, maintainer=maintainer, limit=limit, page=page)

Search APIs

Searching across all APIs by keyword, property type, or maintainer.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.SearchApi()
search = 'search_example' # str | Keyword to search by. (optional)
type = 'type_example' # str | Type to search by. (optional)
maintainer = 'maintainer_example' # str | Maintainer to search by. (optional)
limit = 'limit_example' # str |  (optional)
page = 'page_example' # str |  (optional)

try:
    # Search APIs
    api_response = api_instance.search_apis(search=search, type=type, maintainer=maintainer, limit=limit, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchApi->search_apis: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | **str**| Keyword to search by. | [optional] 
 **type** | **str**| Type to search by. | [optional] 
 **maintainer** | **str**| Maintainer to search by. | [optional] 
 **limit** | **str**|  | [optional] 
 **page** | **str**|  | [optional] 

### Return type

[**Search**](Search.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **search_maintainers**
> Search search_maintainers(search=search, limit=limit, page=page)

Search Maintainers

Search across all maintainers.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.SearchApi()
search = 'search_example' # str | Keyword to search by. (optional)
limit = 'limit_example' # str |  (optional)
page = 'page_example' # str |  (optional)

try:
    # Search Maintainers
    api_response = api_instance.search_maintainers(search=search, limit=limit, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchApi->search_maintainers: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | **str**| Keyword to search by. | [optional] 
 **limit** | **str**|  | [optional] 
 **page** | **str**|  | [optional] 

### Return type

[**Search**](Search.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

