# Contact

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fn** | **str** |  | 
**email** | **str** |  | [optional] 
**organization_name** | **str** |  | [optional] 
**adr** | **str** |  | [optional] 
**tel** | **str** |  | [optional] 
**x_github** | **str** |  | [optional] 
**photo** | **str** |  | [optional] 
**v_card** | **str** |  | [optional] 
**url** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

