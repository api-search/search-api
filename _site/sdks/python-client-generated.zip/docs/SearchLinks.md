# SearchLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_self** | **str** |  | 
**first** | **str** |  | [optional] 
**prev** | **str** |  | [optional] 
**next** | **str** |  | [optional] 
**last** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

