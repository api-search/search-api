# APIsJSON

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | The name of the service described | 
**description** | **str** | Description of the service | 
**url** | **str** | URL where the apis.json file will live | 
**image** | **str** | Image to represent the API | [optional] 
**created** | **date** | Date when the file was created | [optional] 
**modified** | **date** | Date when the file was modified | [optional] 
**specification_version** | **str** | APIs.json spec version, latest is 0.14 | [optional] 
**apis** | [**list[API]**](API.md) | All the APIs of this service | [optional] 
**maintainers** | [**list[Maintainer]**](Maintainer.md) | Maintainers of the apis.json file | [optional] 
**tags** | [**list[Tag]**](Tag.md) | Tags to describe the service | [optional] 
**include** | [**list[Include]**](Include.md) | Links to other apis.json definitions included in this service. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

