# Rule

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **str** |  | [optional] 
**documentation_url** | **str** |  | [optional] 
**recommended** | **bool** |  | [optional] 
**given** | [**Given**](Given.md) |  | 
**resolved** | **bool** |  | [optional] 
**severity** | [**Severity**](Severity.md) |  | [optional] 
**message** | **str** |  | [optional] 
**tags** | **list[str]** |  | [optional] 
**formats** | [**Formats**](Formats.md) |  | [optional] 
**then** | [**list[Then]**](Then.md) |  | 
**type** | **str** |  | [optional] 
**extensions** | **object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

