# SearchMeta

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**search** | **string** |  | [optional] 
**type** | **string** |  | [optional] 
**limit** | **int** |  | 
**page** | **int** |  | 
**total_pages** | **int** |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

