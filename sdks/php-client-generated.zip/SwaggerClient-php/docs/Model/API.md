# API

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | name | 
**description** | **string** | description of the API | 
**image** | **string** | URL of an image representing the API | 
**base_url** | **string** | baseURL | 
**human_url** | **string** | humanURL | 
**tags** | **string[]** | tags to describe the API | [optional] 
**properties** | [**\Swagger\Client\Model\Property[]**](Property.md) | URLs | 
**contact** | [**\Swagger\Client\Model\Contact[]**](Contact.md) | Contact to reach if questions about API | 
**meta** | [**\Swagger\Client\Model\MetaInformation[]**](MetaInformation.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

