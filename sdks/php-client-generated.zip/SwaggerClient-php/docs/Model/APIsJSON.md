# APIsJSON

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | The name of the service described | 
**description** | **string** | Description of the service | 
**url** | **string** | URL where the apis.json file will live | 
**image** | **string** | Image to represent the API | [optional] 
**created** | [**\DateTime**](\DateTime.md) | Date when the file was created | [optional] 
**modified** | [**\DateTime**](\DateTime.md) | Date when the file was modified | [optional] 
**specification_version** | **string** | APIs.json spec version, latest is 0.14 | [optional] 
**apis** | [**\Swagger\Client\Model\API[]**](API.md) | All the APIs of this service | [optional] 
**maintainers** | [**\Swagger\Client\Model\Maintainer[]**](Maintainer.md) | Maintainers of the apis.json file | [optional] 
**tags** | [**\Swagger\Client\Model\Tag[]**](Tag.md) | Tags to describe the service | [optional] 
**include** | [**\Swagger\Client\Model\ModelInclude[]**](ModelInclude.md) | Links to other apis.json definitions included in this service. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

