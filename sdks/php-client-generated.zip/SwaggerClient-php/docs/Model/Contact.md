# Contact

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fn** | **string** |  | 
**email** | **string** |  | [optional] 
**organization_name** | **string** |  | [optional] 
**adr** | **string** |  | [optional] 
**tel** | **string** |  | [optional] 
**x_github** | **string** |  | [optional] 
**photo** | **string** |  | [optional] 
**v_card** | **string** |  | [optional] 
**url** | **string** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

