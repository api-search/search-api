# Search

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta** | [**\Swagger\Client\Model\SearchMeta**](SearchMeta.md) |  | 
**data** | [**\Swagger\Client\Model\AnyOfSearchDataItems[]**](.md) | Listing of APIs in the JSON API format. | 
**links** | [**\Swagger\Client\Model\SearchLinks**](SearchLinks.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

