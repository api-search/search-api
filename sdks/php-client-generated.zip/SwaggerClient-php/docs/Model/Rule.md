# Rule

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **string** |  | [optional] 
**documentation_url** | **string** |  | [optional] 
**recommended** | **bool** |  | [optional] 
**given** | [**\Swagger\Client\Model\Given**](Given.md) |  | 
**resolved** | **bool** |  | [optional] 
**severity** | [**\Swagger\Client\Model\Severity**](Severity.md) |  | [optional] 
**message** | **string** |  | [optional] 
**tags** | **string[]** |  | [optional] 
**formats** | [**\Swagger\Client\Model\Formats**](Formats.md) |  | [optional] 
**then** | [**\Swagger\Client\Model\Then[]**](Then.md) |  | 
**type** | **string** |  | [optional] 
**extensions** | **object** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

