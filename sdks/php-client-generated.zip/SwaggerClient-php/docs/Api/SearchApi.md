# Swagger\Client\SearchApi

All URIs are relative to *https://ibmwu99rx3.execute-api.us-east-1.amazonaws.com/staging*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addAPI**](SearchApi.md#addapi) | **POST** /search/apis | Submit API
[**searchAPIs**](SearchApi.md#searchapis) | **GET** /search/apis | Search APIs
[**searchMaintainers**](SearchApi.md#searchmaintainers) | **GET** /search/maintainers | Search Maintainers

# **addAPI**
> \Swagger\Client\Model\APIsJSON addAPI($body)

Submit API

Submit an API to be included in the index.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
// Configure API key authorization: api_key
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// $config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$apiInstance = new Swagger\Client\Api\SearchApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\APIsJSON(); // \Swagger\Client\Model\APIsJSON | 

try {
    $result = $apiInstance->addAPI($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SearchApi->addAPI: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\APIsJSON**](../Model/APIsJSON.md)|  |

### Return type

[**\Swagger\Client\Model\APIsJSON**](../Model/APIsJSON.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **searchAPIs**
> \Swagger\Client\Model\Search searchAPIs($search, $type, $maintainer, $limit, $page)

Search APIs

Searching across all APIs by keyword, property type, or maintainer.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\SearchApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$search = "search_example"; // string | Keyword to search by.
$type = "type_example"; // string | Type to search by.
$maintainer = "maintainer_example"; // string | Maintainer to search by.
$limit = "limit_example"; // string | 
$page = "page_example"; // string | 

try {
    $result = $apiInstance->searchAPIs($search, $type, $maintainer, $limit, $page);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SearchApi->searchAPIs: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | **string**| Keyword to search by. | [optional]
 **type** | **string**| Type to search by. | [optional]
 **maintainer** | **string**| Maintainer to search by. | [optional]
 **limit** | **string**|  | [optional]
 **page** | **string**|  | [optional]

### Return type

[**\Swagger\Client\Model\Search**](../Model/Search.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **searchMaintainers**
> \Swagger\Client\Model\Search searchMaintainers($search, $limit, $page)

Search Maintainers

Search across all maintainers.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\SearchApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$search = "search_example"; // string | Keyword to search by.
$limit = "limit_example"; // string | 
$page = "page_example"; // string | 

try {
    $result = $apiInstance->searchMaintainers($search, $limit, $page);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SearchApi->searchMaintainers: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | **string**| Keyword to search by. | [optional]
 **limit** | **string**|  | [optional]
 **page** | **string**|  | [optional]

### Return type

[**\Swagger\Client\Model\Search**](../Model/Search.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

