# DiagnosticSeverity

## Enum

* `NUMBER_MINUS_1` (value: `new BigDecimal(-1)`)
* `NUMBER_0` (value: `new BigDecimal(0)`)
* `NUMBER_1` (value: `new BigDecimal(1)`)
* `NUMBER_2` (value: `new BigDecimal(2)`)
* `NUMBER_3` (value: `new BigDecimal(3)`)
