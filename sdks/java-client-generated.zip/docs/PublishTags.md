# PublishTags

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** |  |  [optional]
**description** | **String** |  | 
**run** | **String** |  | 
