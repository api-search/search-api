# APIsJSON

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | The name of the service described | 
**description** | **String** | Description of the service | 
**url** | **String** | URL where the apis.json file will live | 
**image** | **String** | Image to represent the API |  [optional]
**created** | [**LocalDate**](LocalDate.md) | Date when the file was created |  [optional]
**modified** | [**LocalDate**](LocalDate.md) | Date when the file was modified |  [optional]
**specificationVersion** | **String** | APIs.json spec version, latest is 0.14 |  [optional]
**apis** | [**List&lt;API&gt;**](API.md) | All the APIs of this service |  [optional]
**maintainers** | [**List&lt;Maintainer&gt;**](Maintainer.md) | Maintainers of the apis.json file |  [optional]
**tags** | [**List&lt;Tag&gt;**](Tag.md) | Tags to describe the service |  [optional]
**include** | [**List&lt;Include&gt;**](Include.md) | Links to other apis.json definitions included in this service. |  [optional]
