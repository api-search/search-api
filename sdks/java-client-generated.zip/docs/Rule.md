# Rule

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **String** |  |  [optional]
**documentationUrl** | **String** |  |  [optional]
**recommended** | **Boolean** |  |  [optional]
**given** | [**Given**](Given.md) |  | 
**resolved** | **Boolean** |  |  [optional]
**severity** | [**Severity**](Severity.md) |  |  [optional]
**message** | **String** |  |  [optional]
**tags** | **List&lt;String&gt;** |  |  [optional]
**formats** | [**Formats**](Formats.md) |  |  [optional]
**then** | [**List&lt;Then&gt;**](Then.md) |  | 
**type** | [**TypeEnum**](#TypeEnum) |  |  [optional]
**extensions** | **Object** |  |  [optional]

<a name="TypeEnum"></a>
## Enum: TypeEnum
Name | Value
---- | -----
STYLE | &quot;style&quot;
VALIDATION | &quot;validation&quot;
