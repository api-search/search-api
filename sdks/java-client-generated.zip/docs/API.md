# API

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | name | 
**description** | **String** | description of the API | 
**image** | **String** | URL of an image representing the API | 
**baseURL** | **String** | baseURL | 
**humanURL** | **String** | humanURL | 
**tags** | **List&lt;String&gt;** | tags to describe the API |  [optional]
**properties** | [**List&lt;Property&gt;**](Property.md) | URLs | 
**contact** | [**List&lt;Contact&gt;**](Contact.md) | Contact to reach if questions about API | 
**meta** | [**List&lt;MetaInformation&gt;**](MetaInformation.md) |  |  [optional]
