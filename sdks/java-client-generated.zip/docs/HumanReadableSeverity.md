# HumanReadableSeverity

## Enum

* `ERROR` (value: `"error"`)
* `WARN` (value: `"warn"`)
* `INFO` (value: `"info"`)
* `HINT` (value: `"hint"`)
* `OFF` (value: `"off"`)
