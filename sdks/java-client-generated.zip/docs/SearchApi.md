# SearchApi

All URIs are relative to *https://ibmwu99rx3.execute-api.us-east-1.amazonaws.com/staging*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addAPI**](SearchApi.md#addAPI) | **POST** /search/apis | Submit API
[**searchAPIs**](SearchApi.md#searchAPIs) | **GET** /search/apis | Search APIs
[**searchMaintainers**](SearchApi.md#searchMaintainers) | **GET** /search/maintainers | Search Maintainers

<a name="addAPI"></a>
# **addAPI**
> APIsJSON addAPI(body)

Submit API

Submit an API to be included in the index.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
APIsJSON body = new APIsJSON(); // APIsJSON | 
try {
    APIsJSON result = apiInstance.addAPI(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#addAPI");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**APIsJSON**](APIsJSON.md)|  |

### Return type

[**APIsJSON**](APIsJSON.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchAPIs"></a>
# **searchAPIs**
> Search searchAPIs(search, type, maintainer, limit, page)

Search APIs

Searching across all APIs by keyword, property type, or maintainer.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.SearchApi;


SearchApi apiInstance = new SearchApi();
String search = "search_example"; // String | Keyword to search by.
String type = "type_example"; // String | Type to search by.
String maintainer = "maintainer_example"; // String | Maintainer to search by.
String limit = "limit_example"; // String | 
String page = "page_example"; // String | 
try {
    Search result = apiInstance.searchAPIs(search, type, maintainer, limit, page);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchAPIs");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | **String**| Keyword to search by. | [optional]
 **type** | **String**| Type to search by. | [optional]
 **maintainer** | **String**| Maintainer to search by. | [optional]
 **limit** | **String**|  | [optional]
 **page** | **String**|  | [optional]

### Return type

[**Search**](Search.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="searchMaintainers"></a>
# **searchMaintainers**
> Search searchMaintainers(search, limit, page)

Search Maintainers

Search across all maintainers.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.SearchApi;


SearchApi apiInstance = new SearchApi();
String search = "search_example"; // String | Keyword to search by.
String limit = "limit_example"; // String | 
String page = "page_example"; // String | 
try {
    Search result = apiInstance.searchMaintainers(search, limit, page);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchMaintainers");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | **String**| Keyword to search by. | [optional]
 **limit** | **String**|  | [optional]
 **page** | **String**|  | [optional]

### Return type

[**Search**](Search.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

