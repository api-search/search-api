# Severity

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
