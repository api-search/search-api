# Search

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta** | [**SearchMeta**](SearchMeta.md) |  | 
**data** | **List&lt;AnyOfSearchDataItems&gt;** | Listing of APIs in the JSON API format. | 
**links** | [**SearchLinks**](SearchLinks.md) |  | 
