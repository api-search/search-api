# SwaggerClient::HumanReadableSeverity

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

