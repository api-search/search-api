# SwaggerClient::Rule

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **String** |  | [optional] 
**documentation_url** | **String** |  | [optional] 
**recommended** | **BOOLEAN** |  | [optional] 
**given** | [**Given**](Given.md) |  | 
**resolved** | **BOOLEAN** |  | [optional] 
**severity** | [**Severity**](Severity.md) |  | [optional] 
**message** | **String** |  | [optional] 
**tags** | **Array&lt;String&gt;** |  | [optional] 
**formats** | [**Formats**](Formats.md) |  | [optional] 
**_then** | [**Array&lt;ModelThen&gt;**](ModelThen.md) |  | 
**type** | **String** |  | [optional] 
**extensions** | **Object** |  | [optional] 

