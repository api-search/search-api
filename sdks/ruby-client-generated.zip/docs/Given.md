# SwaggerClient::Given

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

