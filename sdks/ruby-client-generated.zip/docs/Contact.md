# SwaggerClient::Contact

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fn** | **String** |  | 
**email** | **String** |  | [optional] 
**organization_name** | **String** |  | [optional] 
**adr** | **String** |  | [optional] 
**tel** | **String** |  | [optional] 
**x_github** | **String** |  | [optional] 
**photo** | **String** |  | [optional] 
**v_card** | **String** |  | [optional] 
**url** | **String** |  | [optional] 

