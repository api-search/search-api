# SwaggerClient::SearchMeta

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**search** | **String** |  | [optional] 
**type** | **String** |  | [optional] 
**limit** | **Integer** |  | 
**page** | **Integer** |  | 
**total_pages** | **Integer** |  | 

