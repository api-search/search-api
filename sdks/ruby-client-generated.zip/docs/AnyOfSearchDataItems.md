# SwaggerClient::AnyOfSearchDataItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

