# SwaggerClient::API

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | name | 
**description** | **String** | description of the API | 
**image** | **String** | URL of an image representing the API | 
**base_url** | **String** | baseURL | 
**human_url** | **String** | humanURL | 
**tags** | **Array&lt;String&gt;** | tags to describe the API | [optional] 
**properties** | [**Array&lt;Property&gt;**](Property.md) | URLs | 
**contact** | [**Array&lt;Contact&gt;**](Contact.md) | Contact to reach if questions about API | 
**meta** | [**Array&lt;MetaInformation&gt;**](MetaInformation.md) |  | [optional] 

