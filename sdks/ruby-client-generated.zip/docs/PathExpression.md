# SwaggerClient::PathExpression

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

