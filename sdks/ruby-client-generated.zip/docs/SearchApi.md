# SwaggerClient::SearchApi

All URIs are relative to *https://ibmwu99rx3.execute-api.us-east-1.amazonaws.com/staging*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add_api**](SearchApi.md#add_api) | **POST** /search/apis | Submit API
[**search_apis**](SearchApi.md#search_apis) | **GET** /search/apis | Search APIs
[**search_maintainers**](SearchApi.md#search_maintainers) | **GET** /search/maintainers | Search Maintainers

# **add_api**
> APIsJSON add_api(body)

Submit API

Submit an API to be included in the index.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure API key authorization: api_key
  config.api_key['x-api-key'] = 'YOUR API KEY'
  # Uncomment the following line to set a prefix for the API key, e.g. 'Bearer' (defaults to nil)
  #config.api_key_prefix['x-api-key'] = 'Bearer'
end

api_instance = SwaggerClient::SearchApi.new
body = SwaggerClient::APIsJSON.new # APIsJSON | 


begin
  #Submit API
  result = api_instance.add_api(body)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SearchApi->add_api: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**APIsJSON**](APIsJSON.md)|  | 

### Return type

[**APIsJSON**](APIsJSON.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **search_apis**
> Search search_apis(opts)

Search APIs

Searching across all APIs by keyword, property type, or maintainer.

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::SearchApi.new
opts = { 
  search: 'search_example', # String | Keyword to search by.
  type: 'type_example', # String | Type to search by.
  maintainer: 'maintainer_example', # String | Maintainer to search by.
  limit: 'limit_example', # String | 
  page: 'page_example' # String | 
}

begin
  #Search APIs
  result = api_instance.search_apis(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SearchApi->search_apis: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | **String**| Keyword to search by. | [optional] 
 **type** | **String**| Type to search by. | [optional] 
 **maintainer** | **String**| Maintainer to search by. | [optional] 
 **limit** | **String**|  | [optional] 
 **page** | **String**|  | [optional] 

### Return type

[**Search**](Search.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json



# **search_maintainers**
> Search search_maintainers(opts)

Search Maintainers

Search across all maintainers.

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::SearchApi.new
opts = { 
  search: 'search_example', # String | Keyword to search by.
  limit: 'limit_example', # String | 
  page: 'page_example' # String | 
}

begin
  #Search Maintainers
  result = api_instance.search_maintainers(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SearchApi->search_maintainers: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | **String**| Keyword to search by. | [optional] 
 **limit** | **String**|  | [optional] 
 **page** | **String**|  | [optional] 

### Return type

[**Search**](Search.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json



