# SwaggerClient::Maintainer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

