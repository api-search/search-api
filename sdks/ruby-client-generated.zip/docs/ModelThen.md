# SwaggerClient::ModelThen

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

