# SwaggerClient::SearchLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_self** | **String** |  | 
**first** | **String** |  | [optional] 
**prev** | **String** |  | [optional] 
**_next** | **String** |  | [optional] 
**last** | **String** |  | [optional] 

