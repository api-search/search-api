# SwaggerClient::DiagnosticSeverity

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

