# SwaggerClient::Search

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta** | [**SearchMeta**](SearchMeta.md) |  | 
**data** | [**Array&lt;AnyOfSearchDataItems&gt;**](.md) | Listing of APIs in the JSON API format. | 
**links** | [**SearchLinks**](SearchLinks.md) |  | 

