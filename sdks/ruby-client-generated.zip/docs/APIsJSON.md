# SwaggerClient::APIsJSON

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | The name of the service described | 
**description** | **String** | Description of the service | 
**url** | **String** | URL where the apis.json file will live | 
**image** | **String** | Image to represent the API | [optional] 
**created** | **Date** | Date when the file was created | [optional] 
**modified** | **Date** | Date when the file was modified | [optional] 
**specification_version** | **String** | APIs.json spec version, latest is 0.14 | [optional] 
**apis** | [**Array&lt;API&gt;**](API.md) | All the APIs of this service | [optional] 
**maintainers** | [**Array&lt;Maintainer&gt;**](Maintainer.md) | Maintainers of the apis.json file | [optional] 
**tags** | [**Array&lt;Tag&gt;**](Tag.md) | Tags to describe the service | [optional] 
**include** | [**Array&lt;Include&gt;**](Include.md) | Links to other apis.json definitions included in this service. | [optional] 

