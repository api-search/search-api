# SwaggerClient::Formats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

