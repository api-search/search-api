# SwaggerClient::Tag

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

