# ApisioSearchApi.API

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | name | 
**description** | **String** | description of the API | 
**image** | **String** | URL of an image representing the API | 
**baseURL** | **String** | baseURL | 
**humanURL** | **String** | humanURL | 
**tags** | **[String]** | tags to describe the API | [optional] 
**properties** | [**[Property]**](Property.md) | URLs | 
**contact** | [**[Contact]**](Contact.md) | Contact to reach if questions about API | 
**meta** | [**[MetaInformation]**](MetaInformation.md) |  | [optional] 
