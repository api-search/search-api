# ApisioSearchApi.PathExpression

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
