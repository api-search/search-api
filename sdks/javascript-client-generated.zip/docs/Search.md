# ApisioSearchApi.Search

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta** | [**SearchMeta**](SearchMeta.md) |  | 
**data** | **[AnyOfSearchDataItems]** | Listing of APIs in the JSON API format. | 
**links** | [**SearchLinks**](SearchLinks.md) |  | 
