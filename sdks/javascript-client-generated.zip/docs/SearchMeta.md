# ApisioSearchApi.SearchMeta

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**search** | **String** |  | [optional] 
**type** | **String** |  | [optional] 
**limit** | **Number** |  | 
**page** | **Number** |  | 
**totalPages** | **Number** |  | 
