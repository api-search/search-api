# ApisioSearchApi.Formats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
