# ApisioSearchApi.Rule

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **String** |  | [optional] 
**documentationUrl** | **String** |  | [optional] 
**recommended** | **Boolean** |  | [optional] 
**given** | [**Given**](Given.md) |  | 
**resolved** | **Boolean** |  | [optional] 
**severity** | [**Severity**](Severity.md) |  | [optional] 
**message** | **String** |  | [optional] 
**tags** | **[String]** |  | [optional] 
**formats** | [**Formats**](Formats.md) |  | [optional] 
**then** | [**[Then]**](Then.md) |  | 
**type** | **String** |  | [optional] 
**extensions** | **Object** |  | [optional] 

<a name="TypeEnum"></a>
## Enum: TypeEnum

* `style` (value: `"style"`)
* `validation` (value: `"validation"`)

