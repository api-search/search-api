# ApisioSearchApi.AnyOfSearchDataItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
