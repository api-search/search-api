# ApisioSearchApi.SearchApi

All URIs are relative to *https://ibmwu99rx3.execute-api.us-east-1.amazonaws.com/staging*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addAPI**](SearchApi.md#addAPI) | **POST** /search/apis | Submit API
[**searchAPIs**](SearchApi.md#searchAPIs) | **GET** /search/apis | Search APIs
[**searchMaintainers**](SearchApi.md#searchMaintainers) | **GET** /search/maintainers | Search Maintainers

<a name="addAPI"></a>
# **addAPI**
> APIsJSON addAPI(body)

Submit API

Submit an API to be included in the index.

### Example
```javascript
import {ApisioSearchApi} from 'apisio_search_api';
let defaultClient = ApisioSearchApi.ApiClient.instance;

// Configure API key authorization: api_key
let api_key = defaultClient.authentications['api_key'];
api_key.apiKey = 'YOUR API KEY';
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.apiKeyPrefix = 'Token';

let apiInstance = new ApisioSearchApi.SearchApi();
let body = new ApisioSearchApi.APIsJSON(); // APIsJSON | 

apiInstance.addAPI(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**APIsJSON**](APIsJSON.md)|  | 

### Return type

[**APIsJSON**](APIsJSON.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchAPIs"></a>
# **searchAPIs**
> Search searchAPIs(opts)

Search APIs

Searching across all APIs by keyword, property type, or maintainer.

### Example
```javascript
import {ApisioSearchApi} from 'apisio_search_api';

let apiInstance = new ApisioSearchApi.SearchApi();
let opts = { 
  'search': "search_example", // String | Keyword to search by.
  'type': "type_example", // String | Type to search by.
  'maintainer': "maintainer_example", // String | Maintainer to search by.
  'limit': "limit_example", // String | 
  'page': "page_example" // String | 
};
apiInstance.searchAPIs(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | **String**| Keyword to search by. | [optional] 
 **type** | **String**| Type to search by. | [optional] 
 **maintainer** | **String**| Maintainer to search by. | [optional] 
 **limit** | **String**|  | [optional] 
 **page** | **String**|  | [optional] 

### Return type

[**Search**](Search.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="searchMaintainers"></a>
# **searchMaintainers**
> Search searchMaintainers(opts)

Search Maintainers

Search across all maintainers.

### Example
```javascript
import {ApisioSearchApi} from 'apisio_search_api';

let apiInstance = new ApisioSearchApi.SearchApi();
let opts = { 
  'search': "search_example", // String | Keyword to search by.
  'limit': "limit_example", // String | 
  'page': "page_example" // String | 
};
apiInstance.searchMaintainers(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | **String**| Keyword to search by. | [optional] 
 **limit** | **String**|  | [optional] 
 **page** | **String**|  | [optional] 

### Return type

[**Search**](Search.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

