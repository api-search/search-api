# ApisioSearchApi.Contact

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FN** | **String** |  | 
**email** | **String** |  | [optional] 
**organizationName** | **String** |  | [optional] 
**adr** | **String** |  | [optional] 
**tel** | **String** |  | [optional] 
**xGithub** | **String** |  | [optional] 
**photo** | **String** |  | [optional] 
**vCard** | **String** |  | [optional] 
**url** | **String** |  | [optional] 
