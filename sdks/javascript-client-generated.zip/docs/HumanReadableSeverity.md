# ApisioSearchApi.HumanReadableSeverity

## Enum

* `error` (value: `"error"`)
* `warn` (value: `"warn"`)
* `info` (value: `"info"`)
* `hint` (value: `"hint"`)
* `off` (value: `"off"`)
