# Api

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | name | [default to null]
**Description** | **string** | description of the API | [default to null]
**Image** | **string** | URL of an image representing the API | [default to null]
**BaseURL** | **string** | baseURL | [default to null]
**HumanURL** | **string** | humanURL | [default to null]
**Tags** | **[]string** | tags to describe the API | [optional] [default to null]
**Properties** | [**[]Property**](Property.md) | URLs | [default to null]
**Contact** | [**[]Contact**](Contact.md) | Contact to reach if questions about API | [default to null]
**Meta** | [**[]MetaInformation**](metaInformation.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

