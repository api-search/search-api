# Rule

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Description** | **string** |  | [optional] [default to null]
**DocumentationUrl** | **string** |  | [optional] [default to null]
**Recommended** | **bool** |  | [optional] [default to null]
**Given** | [***[]string**](array.md) |  | [default to null]
**Resolved** | **bool** |  | [optional] [default to null]
**Severity** | [***Severity**](Severity.md) |  | [optional] [default to null]
**Message** | **string** |  | [optional] [default to null]
**Tags** | **[]string** |  | [optional] [default to null]
**Formats** | [***[]string**](array.md) |  | [optional] [default to null]
**Then** | [**[][]string**](array.md) |  | [default to null]
**Type_** | **string** |  | [optional] [default to null]
**Extensions** | [***interface{}**](interface{}.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

