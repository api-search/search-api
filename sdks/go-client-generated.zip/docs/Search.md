# Search

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Meta** | [***SearchMeta**](Search_meta.md) |  | [default to null]
**Data** | [**[]AnyOfSearchDataItems**](.md) | Listing of APIs in the JSON API format. | [default to null]
**Links** | [***SearchLinks**](Search_links.md) |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

