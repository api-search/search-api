# {{classname}}

All URIs are relative to *https://ibmwu99rx3.execute-api.us-east-1.amazonaws.com/staging*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AddAPI**](SearchApi.md#AddAPI) | **Post** /search/apis | Submit API
[**SearchAPIs**](SearchApi.md#SearchAPIs) | **Get** /search/apis | Search APIs
[**SearchMaintainers**](SearchApi.md#SearchMaintainers) | **Get** /search/maintainers | Search Maintainers

# **AddAPI**
> ApisJson AddAPI(ctx, body)
Submit API

Submit an API to be included in the index.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**ApisJson**](ApisJson.md)|  | 

### Return type

[**ApisJson**](APIsJSON.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SearchAPIs**
> Search SearchAPIs(ctx, optional)
Search APIs

Searching across all APIs by keyword, property type, or maintainer.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***SearchApiSearchAPIsOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a SearchApiSearchAPIsOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | **optional.String**| Keyword to search by. | 
 **type_** | **optional.String**| Type to search by. | 
 **maintainer** | **optional.String**| Maintainer to search by. | 
 **limit** | **optional.String**|  | 
 **page** | **optional.String**|  | 

### Return type

[**Search**](Search.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SearchMaintainers**
> Search SearchMaintainers(ctx, optional)
Search Maintainers

Search across all maintainers.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***SearchApiSearchMaintainersOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a SearchApiSearchMaintainersOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | **optional.String**| Keyword to search by. | 
 **limit** | **optional.String**|  | 
 **page** | **optional.String**|  | 

### Return type

[**Search**](Search.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

