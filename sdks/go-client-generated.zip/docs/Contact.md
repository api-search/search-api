# Contact

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FN** | **string** |  | [default to null]
**Email** | **string** |  | [optional] [default to null]
**OrganizationName** | **string** |  | [optional] [default to null]
**Adr** | **string** |  | [optional] [default to null]
**Tel** | **string** |  | [optional] [default to null]
**XGithub** | **string** |  | [optional] [default to null]
**Photo** | **string** |  | [optional] [default to null]
**VCard** | **string** |  | [optional] [default to null]
**Url** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

