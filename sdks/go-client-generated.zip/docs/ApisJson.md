# ApisJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The name of the service described | [default to null]
**Description** | **string** | Description of the service | [default to null]
**Url** | **string** | URL where the apis.json file will live | [default to null]
**Image** | **string** | Image to represent the API | [optional] [default to null]
**Created** | **string** | Date when the file was created | [optional] [default to null]
**Modified** | **string** | Date when the file was modified | [optional] [default to null]
**SpecificationVersion** | **string** | APIs.json spec version, latest is 0.14 | [optional] [default to null]
**Apis** | [**[]Api**](API.md) | All the APIs of this service | [optional] [default to null]
**Maintainers** | [**[]map[string]string**](map.md) | Maintainers of the apis.json file | [optional] [default to null]
**Tags** | [**[]Object**](.md) | Tags to describe the service | [optional] [default to null]
**Include** | [**[]Include**](Include.md) | Links to other apis.json definitions included in this service. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

