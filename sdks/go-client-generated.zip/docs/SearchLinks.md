# SearchLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Self** | **string** |  | [default to null]
**First** | **string** |  | [optional] [default to null]
**Prev** | **string** |  | [optional] [default to null]
**Next** | **string** |  | [optional] [default to null]
**Last** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

