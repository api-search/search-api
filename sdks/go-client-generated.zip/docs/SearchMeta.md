# SearchMeta

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Search** | **string** |  | [optional] [default to null]
**Type_** | **string** |  | [optional] [default to null]
**Limit** | **int32** |  | [default to null]
**Page** | **int32** |  | [default to null]
**TotalPages** | **int32** |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

